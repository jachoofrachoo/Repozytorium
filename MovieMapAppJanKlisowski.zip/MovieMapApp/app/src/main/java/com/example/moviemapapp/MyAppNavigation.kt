package com.example.moviemapapp

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.moviemapapp.pages.AddReviewPage
import com.example.moviemapapp.pages.HomePage
import com.example.moviemapapp.pages.LocationPage
import com.example.moviemapapp.pages.LoginPage
import com.example.moviemapapp.pages.MapPage
import com.example.moviemapapp.pages.ReviewsPage
import com.example.moviemapapp.pages.SignUpPage

@Composable
fun MyAppNavigation (modifier: Modifier = Modifier, authViewModel: AuthViewModel, filmViewModel: FilmViewModel){
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "login") {
        composable("login") {
            LoginPage(modifier, navController, authViewModel)
        }
        composable("signup") {
            SignUpPage(modifier, navController, authViewModel)
        }
        composable("home") {
            HomePage(modifier, navController, authViewModel, filmViewModel)
        }
        composable("locations/{filmId}") { backStackEntry ->
            val filmId = backStackEntry.arguments?.getString("filmId") ?: return@composable
            LocationPage(
                filmId = filmId,
                navController = navController,
                filmViewModel = filmViewModel
            )
        }
        composable("addReviewPage/{filmId}/{locationId}") { backStackEntry ->
            val filmId = backStackEntry.arguments?.getString("filmId") ?: return@composable
            val locationId = backStackEntry.arguments?.getString("locationId") ?: return@composable
            AddReviewPage(
                filmId = filmId,
                locationId = locationId,
                navController = navController,
                filmViewModel = filmViewModel
            )
        }
        composable("reviewsPage/{filmId}/{locationId}") { backStackEntry ->
            val filmId = backStackEntry.arguments?.getString("filmId") ?: return@composable
            val locationId = backStackEntry.arguments?.getString("locationId") ?: return@composable
            ReviewsPage(
                filmId = filmId,
                locationId = locationId,
                filmViewModel = filmViewModel
            )
        }
        composable("mapPage/{latitude}/{longitude}") { backStackEntry ->
            val latitude = backStackEntry.arguments?.getString("latitude")?.toDoubleOrNull() ?: 0.0
            val longitude = backStackEntry.arguments?.getString("longitude")?.toDoubleOrNull() ?: 0.0
            MapPage(
                latitude = latitude,
                longitude = longitude,
            )
        }
    }
}