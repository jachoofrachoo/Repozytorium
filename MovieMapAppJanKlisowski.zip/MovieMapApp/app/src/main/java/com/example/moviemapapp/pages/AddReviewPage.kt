package com.example.moviemapapp.pages

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.moviemapapp.FilmViewModel
import com.example.moviemapapp.data.Review
import com.google.firebase.Timestamp

@Composable
fun AddReviewPage(
    filmId: String,
    locationId: String,
    navController: NavController,
    filmViewModel: FilmViewModel
) {
    var rating by remember { mutableDoubleStateOf(0.0) }
    var opinionText by remember { mutableStateOf("") }
    val userId = filmViewModel.getCurrentUserId() ?: "unknown"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "Dodaj opinię", style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = Modifier.height(16.dp))

        StarRating(
            rating = rating,
            onRatingChanged = { rating = it }
        )

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = opinionText,
            onValueChange = { opinionText = it },
            label = { Text("Twoja opinia") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                val review = Review(
                    userId = userId,
                    rating = rating,
                    opinion = opinionText,
                    time = Timestamp.now()
                )
                filmViewModel.addReview(filmId, locationId, review)
                navController.popBackStack()
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color.Black),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Text(text = "Dodaj opinię", color = Color.White)
        }
    }
}

@Composable
fun StarRating(
    rating: Double,
    onRatingChanged: (Double) -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
        modifier = Modifier.fillMaxWidth()
    ) {
        for (i in 1..5) {
            val isHalf = rating >= i - 0.5 && rating < i
            Icon(
                imageVector = Icons.Filled.Star,
                contentDescription = null,
                tint = if (rating >= i || isHalf) Color.Yellow else Color.Gray,
                modifier = Modifier
                    .size(32.dp)
                    .clickable {
                        onRatingChanged(if (isHalf) i - 1.5 else i.toDouble())
                    }
            )
        }
    }

    Text(
        text = "Twoja ocena: $rating gwiazdek",
        modifier = Modifier.padding(top = 8.dp)
    )
}


