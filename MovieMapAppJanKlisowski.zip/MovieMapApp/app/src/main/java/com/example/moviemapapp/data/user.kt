package com.example.moviemapapp.data

data class user(
    var userid: String = "",
    val username: String = "",
    val email: String = ""
)