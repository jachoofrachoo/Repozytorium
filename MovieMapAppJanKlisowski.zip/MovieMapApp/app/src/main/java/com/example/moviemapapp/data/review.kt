package com.example.moviemapapp.data

import com.google.firebase.Timestamp

data class Review(
    val userId: String = "",
    val rating: Double = 0.0,
    val opinion: String = "",
    val time: Timestamp = Timestamp.now()
)
