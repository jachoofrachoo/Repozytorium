package com.example.moviemapapp.data

data class Location(
    var locationId: String = "",
    val locationName: String = "",
    val coordinates: Coordinates = Coordinates(),
    val shortDescription: String = "",
    val averageRating: Double = 0.0,
    val reviews: List<Review> = emptyList(),
    val adress: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val url: String = ""
)

data class Coordinates(
    val latitude: Double = 0.0,
    val longitude: Double = 0.0
)
