package com.example.moviemapapp.pages

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.moviemapapp.FilmViewModel
import com.example.moviemapapp.data.Review
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import com.google.accompanist.swiperefresh.SwipeRefresh
import com.google.accompanist.swiperefresh.rememberSwipeRefreshState

@Composable
fun ReviewsPage(
    filmId: String,
    locationId: String,
    filmViewModel: FilmViewModel
) {
    val reviews = filmViewModel.reviews.observeAsState(emptyList())
    val userLogins = filmViewModel.userLogins.observeAsState(emptyMap())
    val isRefreshing = remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        filmViewModel.fetchReviewsForLocation(filmId, locationId)
        filmViewModel.fetchUserLogins()
    }

    SwipeRefresh(
        state = rememberSwipeRefreshState(isRefreshing.value),
        onRefresh = {
            isRefreshing.value = true
            filmViewModel.fetchLocationsForFilm(filmId)
            isRefreshing.value = false
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Text(text = "Opinie", fontSize = 24.sp)

            Spacer(modifier = Modifier.height(16.dp))

            if (reviews.value.isEmpty()) {
                Text(
                    text = "Brak opinii dla tej lokalizacji.",
                    fontSize = 16.sp,
                    modifier = Modifier.padding(16.dp)
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(reviews.value) { review ->
                        ReviewItem(review = review, userLogins = userLogins.value)
                    }
                }
            }
        }
    }
}

@Composable
fun ReviewItem(review: Review, userLogins: Map<String, String>) {
    val username = userLogins[review.userId] ?: "Anonim"
    Card(
        shape = RoundedCornerShape(12.dp), // Zaokrąglone rogi kafelka
        colors = CardDefaults.cardColors(containerColor = Color.White), // Kolor tła kafelka
        elevation = CardDefaults.cardElevation(8.dp), // Cień dla kafelka
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(text = "Użytkownik: $username", fontSize = 14.sp, color = Color.Black)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "Ocena: ${review.rating}", fontSize = 14.sp, color = Color.Black)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "Opinia: ${review.opinion}", fontSize = 14.sp, color = Color.Black)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "Data: ${review.time.toDate()}", fontSize = 12.sp, color = Color.Gray)
        }
    }
}


