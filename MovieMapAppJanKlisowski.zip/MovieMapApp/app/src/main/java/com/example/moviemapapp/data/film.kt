package com.example.moviemapapp.data

data class Film(
    var FilmId: String = "",
    val filmName: String = "",
    val year: Int = 0,
    val director: String = "",
    val locations: List<Location> = emptyList(),
    val coverUrl: String = "",
    val id: String = "",
    val filmwebUrl: String = ""
)
