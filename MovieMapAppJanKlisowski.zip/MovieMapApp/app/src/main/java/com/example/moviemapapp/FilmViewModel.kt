package com.example.moviemapapp

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.FirebaseFirestore
import com.example.moviemapapp.data.Film
import com.example.moviemapapp.data.Location
import com.example.moviemapapp.data.Review
import com.google.firebase.auth.FirebaseAuth

class FilmViewModel : ViewModel() {
    private val firestore = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    val films = MutableLiveData<List<Film>>()

    private val _reviews = MutableLiveData<List<Review>>()
    val reviews: LiveData<List<Review>> get() = _reviews

    private val _locations = MutableLiveData<List<Location>>()
    val locations: LiveData<List<Location>> get() = _locations

    private val _userLogins = MutableLiveData<Map<String, String>>()
    val userLogins: LiveData<Map<String, String>> get() = _userLogins

    private val _isRefreshing = MutableLiveData(false)
    val isRefreshing: LiveData<Boolean> get() = _isRefreshing

    fun fetchFilms() {
        firestore.collection("films")
            .get()
            .addOnSuccessListener { documents ->
                val filmList = documents.map { doc ->
                    Film(
                        id = doc.id,
                        filmName = doc.getString("filmName") ?: "Brak tytułu",
                        director = doc.getString("director") ?: "Nieznany reżyser",
                        year = doc.getLong("year")?.toInt() ?: 0,
                        coverUrl = doc.getString("coverUrl") ?: "",
                        filmwebUrl = doc.getString("filmwebUrl") ?: ""
                    )
                }
                films.postValue(filmList)
            }
            .addOnFailureListener { exception ->
                Log.e("FilmViewModel", "Błąd pobierania danych: ", exception)
            }
    }

    // Funkcja pobierająca lokalizacje dla wybranego filmu
    fun fetchLocationsForFilm(filmId: String) {
        firestore.collection("films").document(filmId).collection("locations")
            .get()
            .addOnSuccessListener { documents ->
                val locationList = documents.map { doc ->
                    Location(
                        locationId = doc.id,
                        locationName = doc.getString("locationName") ?: "Brak nazwy",
                        adress = doc.getString("adress") ?: "Brak adresu",
                        latitude = doc.getDouble("coordinates.latitude") ?: 0.0,
                        longitude = doc.getDouble("coordinates.longitude") ?: 0.0,
                        averageRating = doc.getDouble("averageRating") ?: 0.0,
                        url = doc.getString("url") ?: ""
                    )
                }
                _locations.postValue(locationList)
            }
            .addOnFailureListener { exception ->
                Log.e("FilmViewModel", "Błąd pobierania lokalizacji: ", exception)
            }
    }

    // Dodajemy funkcję, aby uzyskać aktualne ID użytkownika
    fun getCurrentUserId(): String? {
        return auth.currentUser?.uid
    }

    fun addReview(filmId: String, locationId: String, review: Review) {
        // Ścieżka do lokalizacji, uwzględniając filmId
        val locationRef = firestore.collection("films").document(filmId)
            .collection("locations").document(locationId)

        Log.d("FilmViewModel", "Rozpoczęcie dodawania opinii dla locationId: $locationId i filmId: $filmId")

        locationRef.collection("reviews").add(review)
            .addOnSuccessListener {
                Log.d("FilmViewModel", "Opinia została dodana pomyślnie.")

                // Obliczenie średniej ocen na podstawie wszystkich opinii
                locationRef.collection("reviews").get()
                    .addOnSuccessListener { reviewsSnapshot ->
                        val reviews = reviewsSnapshot.map { it.toObject(Review::class.java) }
                        val averageRating = reviews.map { it.rating }.average()

                        Log.d("FilmViewModel", "Obliczona średnia ocen: $averageRating")

                        // Aktualizacja pola averageRating w dokumencie locationId1
                        locationRef.update("averageRating", averageRating)
                            .addOnSuccessListener {
                                Log.d("FilmViewModel", "Średnia ocen została zaktualizowana.")
                            }
                            .addOnFailureListener { e ->
                                Log.e("FilmViewModel", "Błąd aktualizacji średniej ocen: ", e)
                            }
                    }
                    .addOnFailureListener { e ->
                        Log.e("FilmViewModel", "Błąd pobierania opinii: ", e)
                    }
            }
            .addOnFailureListener { e ->
                Log.e("FilmViewModel", "Błąd dodania opinii: ", e)
            }
    }

    fun fetchReviewsForLocation(filmId: String, locationId: String) {
        val locationRef = firestore.collection("films").document(filmId)
            .collection("locations").document(locationId)

        locationRef.collection("reviews").get()
            .addOnSuccessListener { documents ->
                val reviewsList = documents.map { it.toObject(Review::class.java) }
                _reviews.postValue(reviewsList)
            }
            .addOnFailureListener { exception ->
                Log.e("FilmViewModel", "Błąd pobierania opinii: ", exception)
            }
    }

    fun fetchUserLogins() {
        firestore.collection("users")
            .get()
            .addOnSuccessListener { documents ->
                val userLoginsMap = documents.associate { doc ->
                    val userId = doc.getString("userid") ?: doc.id
                    val username = doc.getString("username") ?: "Anonim"
                    userId to username
                }
                _userLogins.postValue(userLoginsMap)
            }
            .addOnFailureListener { exception ->
                Log.e("FilmViewModel", "Błąd pobierania użytkowników: ", exception)
            }
    }

    fun refreshData(filmId: String, locationId: String) {
        _isRefreshing.postValue(true)
        fetchReviewsForLocation(filmId, locationId)
        fetchUserLogins()
        _isRefreshing.postValue(false)
    }



}

