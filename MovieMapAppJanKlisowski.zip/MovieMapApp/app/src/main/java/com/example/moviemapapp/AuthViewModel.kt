package com.example.moviemapapp

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.moviemapapp.data.user
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore


class AuthViewModel : ViewModel(){

    private val auth : FirebaseAuth = FirebaseAuth.getInstance()
    private val firestore = FirebaseFirestore.getInstance()
    private val _authState = MutableLiveData<AuthState>()
    val authState : LiveData<AuthState> = _authState

    init {
        checkAuthStatus()
    }

    fun checkAuthStatus(){
        if(auth.currentUser==null){
            _authState.value = AuthState.Unauthenticated
        }else{
            _authState.value = AuthState.Authenticated
        }
    }

    fun login(email : String,password : String){

        if(email.isEmpty() || password.isEmpty()){
            _authState.value = AuthState.Error("Email/hasło nie mogą być puste")
            return
        }
        _authState.value = AuthState.Loading
        auth.signInWithEmailAndPassword(email,password)
            .addOnCompleteListener{task->
                if (task.isSuccessful){
                    _authState.value = AuthState.Authenticated
                }else{
                    _authState.value = AuthState.Error(task.exception?.message?:"Coś poszło nie tak")
                }
            }
    }

    fun signup(username: String, email: String, password: String) {
        if (email.isEmpty() || password.isEmpty() || username.isEmpty()) {
            _authState.value = AuthState.Error("Login, email i hasło nie mogą być puste")
            return
        }

        _authState.value = AuthState.Loading

        firestore.collection("users")
            .whereEqualTo("username", username)
            .get()
            .addOnSuccessListener { querySnapshot ->
                if (querySnapshot.documents.isNotEmpty()) {
                    _authState.value = AuthState.Error("Login jest już zajęty, wybierz inny")
                } else {
                    auth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                val userId = auth.currentUser?.uid ?: return@addOnCompleteListener

                                val user = user(userId, username, email)
                                firestore.collection("users").document(userId).set(user)
                                    .addOnSuccessListener {
                                        _authState.value = AuthState.Authenticated
                                    }
                                    .addOnFailureListener { e ->
                                        _authState.value =
                                            AuthState.Error("Nie udało się zapisać loginu: ${e.message}")
                                    }
                            } else {
                                _authState.value =
                                    AuthState.Error(task.exception?.message ?: "Coś poszło nie tak")
                            }
                        }
                }
            }
            .addOnFailureListener { e ->
                _authState.value = AuthState.Error("Błąd sprawdzania dostępności loginu: ${e.message}")
            }
    }


    fun signout(){
        auth.signOut()
        _authState.value = AuthState.Unauthenticated
    }

    fun resetPassword(email: String) {
        if (email.isEmpty()) {
            _authState.value = AuthState.Error("Email nie może być pusty")
            return
        }

        auth.sendPasswordResetEmail(email)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    _authState.value = AuthState.Success("Link resetujący hasło został wysłany na podany adres e-mail")
                } else {
                    _authState.value = AuthState.Error(task.exception?.message ?: "Coś poszło nie tak")
                }
            }
    }

    fun loginWithUsernameOrEmail(input: String, password: String) {
        if (input.isEmpty() || password.isEmpty()) {
            _authState.value = AuthState.Error("Login/email i hasło nie mogą być puste")
            return
        }
        _authState.value = AuthState.Loading

        if (input.contains("@")) {
            auth.signInWithEmailAndPassword(input, password)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        _authState.value = AuthState.Authenticated
                    } else {
                        _authState.value = AuthState.Error(task.exception?.message ?: "Coś poszło nie tak")
                    }
                }
        } else {
            firestore.collection("users")
                .whereEqualTo("username", input)
                .get()
                .addOnSuccessListener { querySnapshot ->
                    if (querySnapshot.documents.isNotEmpty()) {
                        val email = querySnapshot.documents[0].getString("email")
                        if (email != null) {
                            auth.signInWithEmailAndPassword(email, password)
                                .addOnCompleteListener { task ->
                                    if (task.isSuccessful) {
                                        _authState.value = AuthState.Authenticated
                                    } else {
                                        _authState.value = AuthState.Error(task.exception?.message ?: "Coś poszło nie tak")
                                    }
                                }
                        } else {
                            _authState.value = AuthState.Error("Nie znaleziono adresu e-mail dla podanego loginu")
                        }
                    } else {
                        _authState.value = AuthState.Error("Nie znaleziono użytkownika z podanym loginem")
                    }
                }
                .addOnFailureListener { e ->
                    _authState.value = AuthState.Error("Błąd pobierania użytkownika: ${e.message}")
                }
        }
    }

}



sealed class AuthState{
    object Authenticated : AuthState()
    object Unauthenticated : AuthState()
    object Loading : AuthState()
    data class Success(val message: String) : AuthState()
    data class Error(val message : String) : AuthState()
}